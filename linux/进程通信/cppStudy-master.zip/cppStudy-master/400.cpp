#include <iostream>
#include <string>

using namespace std;

struct Good{
  //public:
  //protected:
  string name = "";
  int amount = 0;
  float price = 0;
  float value = 0;
};

int main(){
  Good d;
  d.name = "aaaa"; 
}
