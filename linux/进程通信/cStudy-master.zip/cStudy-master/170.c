#include <stdio.h>
#include <stdlib.h>

struct Student{
  char *name;
  int age;
  
};

int main(){
  struct Student s1, s2;
  struct Student s[10];
  struct Student *p;
}
