#include <stdio.h>

int main(){
  printf("%d\n",sizeof(int**));
  printf("%d\n",sizeof(double*));

  printf("%d\n",sizeof(char*));
}
