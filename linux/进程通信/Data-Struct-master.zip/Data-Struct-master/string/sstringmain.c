#include "sstring.h"

int main(){
  SString ss;
  init(ss);
}
