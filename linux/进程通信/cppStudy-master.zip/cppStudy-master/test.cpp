#include <iostream>
#include <string>
#include <set>

using namespace std;

int main(){
  cout << "sadfsdf" << endl;
  set<string> aa = {"aaa","sd"};
  auto be = aa.begin();
  cout << *be << endl;
}
