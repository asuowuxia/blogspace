#include <stdio.h>

int main(){
  int a = 1;
  return 0;
}
