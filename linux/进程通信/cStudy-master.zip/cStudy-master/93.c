#include <stdio.h>

typedef struct Test{
  int a;
  
  char pc[]; 
}Test;

int main(){
Test t;  
  int a = 1;
  long b = 2;

  char str[] = "a11111aaa";

  
char c = 'a';

  //char str1[] = "2Hello c Hello c++!";  
  //Test t1;
  printf("%s\n",t.pc);
  //printf("%s\n",t1.pc);  
}
